from django.shortcuts import render,HttpResponse

# Create your views here.
def index(request):
    Age_band=request.POST.get('age_band')
    Sex=request.POST.get('Sex')
    edu=request.POST.get('edu')
    rel=request.POST.get('rel')
    exp=request.POST.get('exp')
    lane=request.POST.get('lane')
    jun=request.POST.get('jun')
    rtype=request.POST.get('rtype')
    lcon=request.POST.get('lcon')
    wcon=request.POST.get('wcon')
    tocol=request.POST.get('tocol')
    vmom=request.POST.get('vmom')
    pmom=request.POST.get('pmom')
    coac=request.POST.get('coac')

    import pandas as pd
    import numpy as np
   




    df=pd.read_csv("C:\\Users\\uday2\\OneDrive\\Desktop\\Road accident prediction\\accident\\templates\\numerical_cleaning_data.csv")
    df.isnull()
    X_train = np.array(df.iloc[:,:14])
    y_train = np.array(df.iloc[:,14:15])


    
    # from imblearn.under_sampling import NearMiss

    # undersample = NearMiss()
    # X_train, y_train = undersample.fit_resample(X_train, y_train)


    
    from sklearn import linear_model
    regr=linear_model.LogisticRegression()
    regr.fit(X_train,y_train)




    if (Sex=='0' or Sex=='1' or Sex=='2' or Sex=='3'):
        Age_band=int(Age_band)
        Sex=int(Sex)
        edu=int(edu)
        rel=int(rel)
        exp=int(exp)
        lane=int(lane)
        jun=int(jun)
        rtype=int(rtype)
        lcon=int(lcon)
        wcon=int(wcon)
        tocol=int(tocol)
        vmom=int(vmom)
        pmom=int(pmom)
        coac=int(coac)


        
    print(Age_band,Sex,edu,rel,exp,lane,jun,rtype,lcon,wcon,tocol,vmom,pmom,coac)
    prediction=[0]
    if (Sex==0 or Sex==1 or Sex==2 or Sex==3):
          prediction[0]=float(regr.predict(np.array([[Age_band,Sex,edu,rel,exp,lane,jun,rtype,lcon,wcon,tocol,vmom,pmom,coac]]))[0])
    prediction=float(prediction[0])
    print(prediction)
    return render(request,'index.html',{'prediction':prediction})


