# Shoping-Complex
A Multuplex with unusual benefits...


This webpage uses sql database, so password for mysql server may vary as per the user.
So programmers are requested to change the password as per their serever
