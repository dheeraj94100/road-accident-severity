#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# In[2]:


df = pd.read_csv(r'E:\semester 3\project\archive_14\cleaned.csv')
X = df[['Age_band_of_driver', 'Sex_of_driver', 'Educational_level',
       'Vehicle_driver_relation', 'Driving_experience', 'Lanes_or_Medians',
       'Types_of_Junction', 'Road_surface_type', 'Light_conditions',
       'Weather_conditions', 'Type_of_collision', 'Vehicle_movement',
       'Pedestrian_movement', 'Cause_of_accident',]]
y = df[['Accident_severity']]


# In[3]:


from sklearn import linear_model


# In[4]:


# Import label encoder
from sklearn import preprocessing

# label_encoder object knows how to understand word labels.
label_encoder = preprocessing.LabelEncoder()

# Encode labels in column 'Age_band_of_driver'.
df1 = pd.Series(label_encoder.fit_transform(df['Age_band_of_driver']))

df.iloc[: , 0:1] = df1


# In[5]:


# Encode labels in column 'Sex_of_driver'.
df2 = pd.Series(label_encoder.fit_transform(df['Sex_of_driver']))

df.iloc[: , 1:2] = df2


# In[6]:


# Encode labels in column 'Educational_level'.
df3 = pd.Series(label_encoder.fit_transform(df['Educational_level']))

df.iloc[: , 2:3] = df3


# In[7]:


# Encode labels in column 'Vehicle_driver_relation'.
df4 = pd.Series(label_encoder.fit_transform(df['Vehicle_driver_relation']))

df.iloc[: , 3:4] = df4


# In[8]:


# Encode labels in column 'Driving_experience'.
df4 = pd.Series(label_encoder.fit_transform(df['Driving_experience']))

df.iloc[: , 4:5] = df4


# In[9]:


# Encode labels in column 'Lanes_or_Medians'.
df5 = pd.Series(label_encoder.fit_transform(df['Lanes_or_Medians']))

df.iloc[: , 5:6] = df5


# In[10]:


# Encode labels in column 'Types_of_Junction'.
df6 = pd.Series(label_encoder.fit_transform(df['Types_of_Junction']))

df.iloc[: , 6:7] = df6


# In[11]:


# Encode labels in column 'Road_surface_type'.
df7 = pd.Series(label_encoder.fit_transform(df['Road_surface_type']))

df.iloc[: , 7:8] = df7


# In[12]:


# Encode labels in column 'Light_conditions'.
df8 = pd.Series(label_encoder.fit_transform(df['Light_conditions']))

df.iloc[: , 8:9] = df8


# In[13]:


# Encode labels in column 'Weather_conditions'.
df9 = pd.Series(label_encoder.fit_transform(df['Weather_conditions']))

df.iloc[: , 9:10] = df9


# In[14]:


# Encode labels in column 'Type_of_collision'.
df10 = pd.Series(label_encoder.fit_transform(df['Type_of_collision']))

df.iloc[: , 10:11] = df10


# In[15]:


# Encode labels in column 'Vehicle_movement'.
df11 = pd.Series(label_encoder.fit_transform(df['Vehicle_movement']))

df.iloc[: , 11:12] = df11


# In[16]:


# Encode labels in column 'Pedestrian_movement'.
df12 = pd.Series(label_encoder.fit_transform(df['Pedestrian_movement']))

df.iloc[: , 12:13] = df12


# In[17]:


# Encode labels in column 'Cause_of_accident'.
df13 = pd.Series(label_encoder.fit_transform(df['Cause_of_accident']))

df.iloc[: , 13:14] = df13


# In[18]:


# Encode labels in column 'Cause_of_accident'.
df14 = pd.Series(label_encoder.fit_transform(df['Accident_severity']))

df.iloc[: , 14:15] = df14


# In[22]:


X = df[['Age_band_of_driver', 'Sex_of_driver', 'Educational_level',
       'Vehicle_driver_relation', 'Driving_experience', 'Lanes_or_Medians',
       'Types_of_Junction', 'Road_surface_type', 'Light_conditions',
       'Weather_conditions', 'Type_of_collision', 'Vehicle_movement',
       'Pedestrian_movement', 'Cause_of_accident']]
y = df['Accident_severity']


# In[23]:


from sklearn.model_selection import train_test_split
  
# split into 70:30 ration
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.3, random_state = 0)


# In[24]:


from imblearn.under_sampling import NearMiss

undersample = NearMiss()
X_train, y_train = undersample.fit_resample(X_train,y_train)


# In[25]:


from sklearn.preprocessing import StandardScaler
sc_x = StandardScaler()
xtrain = sc_x.fit_transform(X_train) 
xtest = sc_x.transform(X_test)
  
print (xtrain[0:100, :])


# In[26]:


from sklearn.linear_model import LogisticRegression
classifier = LogisticRegression(random_state = 0)
classifier.fit(X_train, y_train)


# In[27]:


y_pred = classifier.predict(xtest)


# In[28]:


from sklearn.metrics import accuracy_score
print ("Accuracy : ", accuracy_score(y_test, y_pred))


# In[29]:


a = df.iloc[:,0:14]
b = classifier.predict(df.iloc[:,0:14])


# In[30]:


b = np.array(b)


# In[31]:


b = set(b)


# In[32]:


b


# In[33]:


a = np.array(df.iloc[:,0:14])
predicte = classifier.predict(a)
for i in range(0,len(a)):
    print(predicte[i])


# In[ ]:





# In[ ]:




